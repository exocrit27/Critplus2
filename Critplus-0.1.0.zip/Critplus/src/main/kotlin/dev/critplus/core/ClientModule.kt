package dev.critplus.core

enum class ModuleCategory(val displayName: String) {
    COMBAT("Combat"),
    MOVEMENT("Movement"),
    PLAYER("Player"),
    VISUAL("Visual"),
    UTILITY("Utility")
}

/**
 * Small, deliberately boring module contract.
 * Keep feature logic out of the GUI so modules can later be tested independently.
 */
data class ClientModule(
    val id: String,
    val name: String,
    val description: String,
    val category: ModuleCategory,
    var enabled: Boolean = false
)
