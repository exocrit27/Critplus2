package dev.critplus.core

object ModuleRegistry {
    private val entries = linkedMapOf<String, ClientModule>()

    val all: List<ClientModule>
        get() = entries.values.toList()

    fun register(module: ClientModule) {
        require(module.id !in entries) { "Duplicate module id: ${module.id}" }
        entries[module.id] = module
    }

    fun find(id: String): ClientModule? = entries[id]

    fun byCategory(category: ModuleCategory): List<ClientModule> =
        entries.values.filter { it.category == category }

    fun registerDefaults() {
        if (entries.isNotEmpty()) return

        register(ClientModule("toggle_sprint", "Toggle Sprint", "Keeps sprint active when the game allows it.", ModuleCategory.MOVEMENT))
        register(ClientModule("sprint_reset", "Sprint Reset", "A practice utility placeholder for sprint timing.", ModuleCategory.COMBAT))
        register(ClientModule("fullbright", "Fullbright", "Client-side visibility setting (implementation pending).", ModuleCategory.VISUAL))
        register(ClientModule("coordinates", "Coordinates", "Coordinate HUD widget (implementation pending).", ModuleCategory.VISUAL))
        register(ClientModule("armor_status", "Armor Status", "Compact armor HUD widget (implementation pending).", ModuleCategory.VISUAL))
        register(ClientModule("quick_drop", "Quick Drop", "Inventory quality-of-life shortcut (implementation pending).", ModuleCategory.PLAYER))
        register(ClientModule("sounds", "UI Sounds", "Subtle interface feedback (implementation pending).", ModuleCategory.UTILITY))
    }
}
