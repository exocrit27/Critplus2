package dev.critplus

import dev.critplus.core.ModuleRegistry
import dev.critplus.ui.CritplusClickGui
import net.fabricmc.api.ClientModInitializer
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper
import net.minecraft.client.KeyMapping
import net.minecraft.client.Minecraft
import net.minecraft.network.chat.Component
import com.mojang.blaze3d.platform.InputConstants
import org.lwjgl.glfw.GLFW

class CritplusClient : ClientModInitializer {
    companion object {
        const val MOD_ID = "critplus"
        lateinit var clickGuiKey: KeyMapping
            private set
    }

    override fun onInitializeClient() {
        ModuleRegistry.registerDefaults()

        clickGuiKey = KeyBindingHelper.registerKeyBinding(
            KeyMapping(
                "key.critplus.clickgui",
                InputConstants.Type.KEYSYM,
                GLFW.GLFW_KEY_RIGHT_SHIFT,
                KeyMapping.Category.MISC
            )
        )

        ClientTickEvents.END_CLIENT_TICK.register { client ->
            while (clickGuiKey.consumeClick()) {
                if (client.screen == null) {
                    client.setScreen(CritplusClickGui())
                }
            }
        }

        println("[Critplus] Initialized. Press Right Shift to open ClickGUI.")
    }
}
