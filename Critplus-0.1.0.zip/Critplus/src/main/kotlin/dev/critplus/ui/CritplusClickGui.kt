package dev.critplus.ui

import dev.critplus.core.ModuleCategory
import dev.critplus.core.ModuleRegistry
import net.minecraft.client.gui.GuiGraphicsExtractor
import net.minecraft.client.gui.components.Button
import net.minecraft.client.gui.screens.Screen
import net.minecraft.network.chat.Component

/**
 * First native ClickGUI pass: custom dark shell + functional module toggles.
 * UI polish and settings widgets are intentionally isolated here.
 */
class CritplusClickGui : Screen(Component.literal("Critplus")) {
    private var selectedCategory = ModuleCategory.MOVEMENT

    override fun init() {
        clearWidgets()

        val panelWidth = 520
        val left = (width - panelWidth) / 2
        val top = (height - 330) / 2

        var categoryY = top + 82
        ModuleCategory.entries.forEach { category ->
            val selected = category == selectedCategory
            addRenderableWidget(
                Button.builder(Component.literal((if (selected) "◆  " else "   ") + category.displayName)) {
                    selectedCategory = category
                    rebuildWidgets()
                }.bounds(left + 18, categoryY, 124, 25).build()
            )
            categoryY += 31
        }

        val modules = ModuleRegistry.byCategory(selectedCategory)
        modules.forEachIndexed { index, module ->
            val y = top + 82 + index * 48
            addRenderableWidget(
                Button.builder(Component.literal("${module.name}   ·   ${if (module.enabled) "ON" else "OFF"}")) {
                    module.enabled = !module.enabled
                    rebuildWidgets()
                }.bounds(left + 166, y, 330, 34).build()
            )
        }

        addRenderableWidget(
            Button.builder(Component.literal("Done")) { onClose() }
                .bounds(left + panelWidth - 92, top + 286, 74, 24).build()
        )
    }

    override fun extractRenderState(
        context: GuiGraphicsExtractor,
        mouseX: Int,
        mouseY: Int,
        partialTick: Float
    ) {
        val panelWidth = 520
        val panelHeight = 330
        val left = (width - panelWidth) / 2
        val top = (height - panelHeight) / 2

        // Dim the game behind the interface, then draw the Critplus shell.
        context.fill(0, 0, width, height, 0x99070A12.toInt())
        context.fill(left, top, left + panelWidth, top + panelHeight, 0xF0141926.toInt())
        context.fill(left, top, left + panelWidth, top + 2, 0xFF9B7BFF.toInt())
        context.fill(left + 14, top + 14, left + 150, top + 66, 0xFF1D2434.toInt())
        context.fill(left + 158, top + 72, left + panelWidth - 14, top + panelHeight - 42, 0x99101825.toInt())

        context.text(font, "CRITPLUS", left + 27, top + 22, 0xFFFFFFFF.toInt(), true)
        context.text(font, "HYBRID CLIENT  /  26.3", left + 27, top + 43, 0xFF9AA6BC.toInt(), false)
        context.text(font, selectedCategory.displayName.uppercase(), left + 174, top + 22, 0xFFE5DFFF.toInt(), true)
        context.text(font, "Select a module to toggle it", left + 174, top + 42, 0xFF8995AA.toInt(), false)
        context.text(font, "RIGHT SHIFT  ·  CLOSE WITH ESC", left + 18, top + panelHeight - 24, 0xFF758198.toInt(), false)
        context.text(font, "BUILD 0.1.0", left + panelWidth - 94, top + panelHeight - 24, 0xFF758198.toInt(), false)

        // Render interactive widgets above the custom panel.
        super.extractRenderState(context, mouseX, mouseY, partialTick)
    }

    override fun isPauseScreen(): Boolean = false
}
