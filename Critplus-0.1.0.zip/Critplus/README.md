# Critplus

A fresh, original hybrid Fabric client foundation for **Minecraft 26.3**.

## Current foundation

- Fabric 26.3 / Loader 0.19.5 / Fabric API 0.165.0+26.3
- Java 25 and Kotlin 2.4.20
- Right Shift opens a custom native ClickGUI
- Category navigation and working module enabled-state toggles
- Clean separation between core module registry and GUI

## Build

Requirements:
- JDK 25
- Gradle (or add the Gradle wrapper for your platform)
- Internet access for dependency resolution

Run:

```bash
gradle runClient
```

Build the mod:

```bash
gradle build
```

The remapped jar will be under `build/libs/`.

## Important status

This is **Milestone 0.1.0**, a project foundation and UI prototype, not a finished client. The module entries are currently architectural placeholders unless otherwise stated; toggling them currently changes their state in the GUI but does not yet implement gameplay behavior. Next milestones should add:
1. persistent config and module settings,
2. HUD renderer and draggable HUD editor,
3. real client-side QoL modules,
4. visual polish, animations, sounds and profile management,
5. testing against a clean Minecraft 26.3 instance.

## License

This repository is an original Critplus scaffold. Review and choose a license before distributing it. Do not copy third-party code/assets without complying with their licenses.
